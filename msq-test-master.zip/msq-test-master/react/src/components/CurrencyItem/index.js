import CurrencyItem from './CurrencyItem';

export default CurrencyItem;
