import CurrencyContainer from './CurrencyContainer';

export default CurrencyContainer;
