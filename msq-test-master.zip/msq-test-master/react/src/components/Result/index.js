import Result from './Result';

export default Result;
